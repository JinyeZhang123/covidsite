<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    <?php include 'style.css'; ?><?php include 'Patient.css'; ?>
</style>

<body>
    <div id="Continer">
        <div id="Filter">
            <header>
                <img src="/image/logo.png" alt="logo">
                <nav>
                    <ul id="menu">
                        <li><a href="covid.php">Home</a></li>
                        <li><a href="Patient.php">Patient</a></li>
                        <li><a href="work.php">Stuff</a></li>
                        <li><a href="aboutus.php">About Us</a></li>
                        <li><a href="aboutus.php">something</a></li>
                    </ul>
                </nav>
            </header>
            <div id="forms">
                <div id="forms2">
                    <form method="POST">
                        <select name='clinic' id='cars'>
                            <option value='downtownClinic'>downtownClinic</option>
                            <option value='ElmClinic'>ElmClinic</option>
                            <option value='MarkhamClinic'>MarkhamClinic</option>
                            <option value='NorthYorkClinic'>NorthYorkClinic</option>
                            <option value='QueensClinic'>QueensClinic</option>
                            <option value='TorontoClinic'>TorontoClinic</option>
                        </select>
                        <input type="submit" value="submit" class="button">
                    </form>
                </div>
                <?php
                error_reporting(0);
                include 'connectdb.php';
                if (isset($_POST['clinic'])) {
                    $clinic = $_POST["clinic"];
                    $result = $connection->query("select FirstName, LastName FROM doctor D join doctorworksat A on D.ID=A.DoctorId WHERE ClinicName='" . $clinic . "'");
                    $row1 = $result->fetchAll();
                    $result2 = $connection->query("select FirstName, LastName FROM nurse N join nurseworksat A on N.ID=A.NurseID WHERE ClinicName='" . $clinic . "'");
                    $row2 = $result2->fetchAll();
                    echo "<table>";
                    echo "<tr class='list'>";
                    echo "<th>FirstName</th>";
                    echo "<th>LastName</th>";
                    echo "<th>Position</th>";
                    echo "</tr>";

                    for ($i = 0; $i < sizeof($row1); $i++) {
                        echo "<tr class='list'>";
                        echo "<td class='listelement'>";
                        echo $row1[$i]["FirstName"];
                        echo "</td>";
                        echo "<td class='listelement'>";
                        echo $row1[$i]["LastName"];
                        echo "</td>";
                        echo "<td class='listelement'>";
                        echo "Doctor";
                        echo "</td>";
                        echo "</tr>";
                    }
                    for ($i = 0; $i < sizeof($row2); $i++) {
                        echo "<tr class='list'>";
                        echo "<td class='listelement'>";
                        echo $row2[$i]["FirstName"];
                        echo "</td>";
                        echo "<td class='listelement'>";
                        echo $row2[$i]["LastName"];
                        echo "</td>";
                        echo "<td class='listelement'>";
                        echo "Nurse";
                        echo "</td>";
                        echo "</tr>";
                    }
                }

                echo "</table>";
                echo "</div>";





                ?>

            </div>
        </div>

</body>

</html>