<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>vaccine</title>
</head>
<style>
    <?php include 'style.css'; ?><?php include 'Patient.css'; ?>
</style>

<body>
    <div id="Continer">
        <div id="Filter">
            <header>
                <img src="/image/logo.png" alt="logo">
                <nav>
                    <ul id="menu">
                        <li><a href="covid.php">Home</a></li>
                        <li><a href="Patient.php">Patient</a></li>
                        <li><a href="work.php">Stuff</a></li>
                        <li><a href="aboutus.php">About Us</a></li>
                        <li><a href="aboutus.php">something</a></li>
                    </ul>
                </nav>
            </header>
            <div id="forms">

                <?php
                error_reporting(0);
                include 'connectdb.php';
                $fun = $_POST['fun'];
                switch ($fun) {
                    case 'fun3':
                        $result = $connection->query("select CompanyName, DOSES, Name FROM vaccine V join vaxclinic C on V.LotNumber=C.LotNum WHERE CompanyName='Johnson'");
                        break;
                    case 'fun4':
                        $result = $connection->query("select CompanyName, DOSES, Name FROM vaccine V join vaxclinic C on V.LotNumber=C.LotNum WHERE CompanyName='Moderna'");
                        break;
                    case 'fun5':
                        $result = $connection->query("select CompanyName, DOSES, Name FROM vaccine V join vaxclinic C on V.LotNumber=C.LotNum WHERE CompanyName='Pfizer'");
                        break;
                }
                $row2 = $result->fetchAll();
                echo "<div id='table'>";
                echo "<table>";
                echo "<tr class='list'>";
                echo "<th>Company Name</th>";
                echo "<th>Clinic Name</th>";
                echo "<th>Number Of Doses</th>";
                echo "</tr>";
                for ($i = 0; $i < sizeof($row2); $i++) {
                    echo "<tr class='list'>";
                    echo "<td class='listelement'>";
                    echo $row2[$i]["CompanyName"];
                    echo "</td>";
                    echo "<td class='listelement'>";
                    echo $row2[$i]["Name"];
                    echo "</td>";
                    echo "<td class='listelement'>";
                    echo $row2[$i]["DOSES"];
                    echo "</td>";
                    echo "</tr>";
                }
                echo "</table>";
                echo "</div>";


                ?>
            </div>
            <a href="covid.php">Go Back</a>
        </div>
    </div>


</body>

</html>