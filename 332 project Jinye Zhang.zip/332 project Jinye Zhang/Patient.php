<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient</title>
</head>
<style>
    <?php include 'style.css'; ?><?php include 'Patient.css'; ?>
</style>

<?php session_start(); ?>

<body>
    <div id="Continer">
        <div id="Filter">
            <header>
                <img src="/image/logo.png" alt="logo">
                <nav>
                    <ul id="menu">
                        <li><a href="covid.php">Home</a></li>
                        <li><a href="Patient.php">Patient</a></li>
                        <li><a href="work.php">Stuff</a></li>
                        <li><a href="aboutus.php">About Us</a></li>
                        <li><a href="aboutus.php">something</a></li>
                    </ul>
                </nav>
            </header>
            <div id="forms">

                <form name="PatientForm" method="post" action="">
                    <input type="text" value="Enter OHIP Number To Find a Patient" onfocus='clearV(this)' name="PatientInput" id="PatientInput">
                    <input type="submit" value="Submit" name="PatientSubmit" id="PatientSubmit">
                </form>
                <button onclick="show()" id="button">Add Vaccination</button>
                <br>
                <?php

                error_reporting(0);
                include 'connectdb.php';

                $OHIP = $_POST["PatientInput"] ?? "";
                $_SESSION['id'] = $OHIP;
                $result2 = $connection->query("select * FROM patient P join vaccination V on P.Ohip=V.PatientOhip join vaccine E on V.LotNum=E.LotNumber WHERE Ohip='" . $OHIP . "'");
                $row2 = $result2->fetchAll();
                $result6 = $connection->query("select * FROM patient P WHERE Ohip='" . $OHIP . "'");
                $row6 = $result6->fetchAll();
                if ($row2 == false && $OHIP != null && $row6 == false) {
                    echo "<h3>Patient with this Ohip is not in database, please fill the following information to add the Patient</h3>";
                    echo "<form  method='post' action='vet.php'>";
                    echo " <input type='text' value='Enter First Name' onfocus='clearV(this)' name='Fname' class='inputbar'>";
                    echo " <input type='text' value='Enter Last Name' onfocus='clearV(this)' name='Lname' class='inputbar'>";
                    echo " <input type='text' value='Enter Ohip Number' onfocus='clearV(this)' name='Ohip' class='inputbar'>";
                    echo " <input type='text' value='Enter Date Of Birth' onfocus='clearV(this)' name='Birth' class='inputbar'>";
                    echo " <input type='text' value='fun1' name='fun' class='cheat'>";

                    echo "<input type='submit' value='Submit' name='PatientSubmit2' class='button'>";
                    echo "</form>";
                } else if ($row2 == true && $OHIP != null) {
                    echo "<div id='table'>";
                    echo "<table>";
                    echo "<tr class='list'>";
                    echo "<th>FirstName</th>";
                    echo "<th>LastName</th>";
                    echo "<th>Ohip</th>";
                    echo "<th>LotNum</th>";
                    echo "<th>ClinicName</th>";
                    echo "<th>CompanyName</th>";
                    echo "<th>VaccinationDate</th>";
                    echo "</tr>";

                    for ($i = 0; $i < sizeof($row2); $i++) {
                        echo "<tr class='list'>";
                        echo "<td class='listelement'>";
                        echo $row2[$i]["FirstName"];
                        echo "</td>";
                        echo "<td class='listelement'>";
                        echo $row2[$i]["LastName"];
                        echo "</td>";
                        echo "<td class='listelement'>";
                        echo $row2[$i]["Ohip"];
                        echo "</td>";
                        echo "<td class='listelement'>";
                        echo $row2[$i]["LotNum"];
                        echo "</td>";
                        echo "<td class='listelement'>";
                        echo $row2[$i]["ClinicName"];
                        echo "</td>";
                        echo "<td class='listelement'>";
                        echo $row2[$i]["CompanyName"];
                        echo "</td>";
                        echo "<td class='listelement'>";
                        echo $row2[$i]["VaccinationDate"];
                        echo "</td>";
                        echo "</tr>";
                    }

                    echo "</table>";
                    echo "</div>";
                    echo "<script>";
                    echo "document.getElementById('button').style.visibility = 'visible';";
                    echo "</script>";
                    echo "<form  method='post' action='vet.php' id='PatientForm'>";
                    echo " <input type='text' value='Enter Vaccination Time' onfocus='clearV(this)' name='time'>";

                    echo " <select name='clinic' id='cars'>";
                    echo "  <option value='downtownClinic'>downtownClinic</option>";
                    echo "  <option value='ElmClinic'>ElmClinic</option>";
                    echo "  <option value='MarkhamClinic'>MarkhamClinic</option>";
                    echo "  <option value='NorthYorkClinic'>NorthYorkClinic</option>";
                    echo "  <option value='QueensClinic'>QueensClinic</option>";
                    echo "  <option value='TorontoClinic'>TorontoClinic</option>";
                    echo " </select>";
                    echo " <input type='text' value='Enter Vaccination Date' onfocus='clearV(this)' name='date'>";
                    echo " <input type='text' value='Enter Vaccine Lotnumber' onfocus='clearV(this)' name='lotnum'>";
                    echo " <input type='text' value='fun2' name='fun' class='cheat'>";
                    echo "<input type='submit' value='Submit' name='PatientSubmit3' id='PatientSubmit3' class='button'>";
                    echo "</form>";
                } else if ($row2 == false && $OHIP != null && $row6 == true) {
                    echo "<script>";
                    echo "document.getElementById('button').style.visibility = 'visible';";
                    echo "</script>";
                    echo "<form  method='post' action='vet.php' id='PatientForm'>";
                    echo " <input type='text' value='Enter Vaccination Time' onfocus='clearV(this)' name='time'>";

                    echo " <select name='clinic' id='cars'>";
                    echo "  <option value='downtownClinic'>downtownClinic</option>";
                    echo "  <option value='ElmClinic'>ElmClinic</option>";
                    echo "  <option value='MarkhamClinic'>MarkhamClinic</option>";
                    echo "  <option value='NorthYorkClinic'>NorthYorkClinic</option>";
                    echo "  <option value='QueensClinic'>QueensClinic</option>";
                    echo "  <option value='TorontoClinic'>TorontoClinic</option>";
                    echo " </select>";
                    echo " <input type='text' value='Enter Vaccination Date' onfocus='clearV(this)' name='date'>";
                    echo " <input type='text' value='Enter Vaccine Lotnumber' onfocus='clearV(this)' name='lotnum'>";
                    echo " <input type='text' value='fun2' name='fun' class='cheat'>";
                    echo "<input type='submit' value='Submit' name='PatientSubmit3' id='PatientSubmit3' class='button'>";
                    echo "</form>";
                }

                ?>
                <script>
                    function show() {
                        console.log("hello");

                        if (document.getElementById("PatientForm").style.visibility == "hidden") {
                            document.getElementById("PatientForm").style.visibility = "visible";
                            console.log("hello1");
                        } else {
                            document.getElementById("PatientForm").style.visibility = "hidden";
                            console.log("hello2");
                        }
                    }

                    function clearV(x) {
                        x.value = "";
                    }
                </script>
            </div>
        </div>
    </div>
</body>

</html>