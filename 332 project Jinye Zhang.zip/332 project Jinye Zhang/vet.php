<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Vet Clinic</title>

</head>
<style>
    <?php include 'style.css'; ?><?php include 'Patient.css'; ?>
</style>
<?php session_start(); ?>

<body>
    <div id="Continer">
        <div id="Filter">
            <header>
                <img src="/image/logo.png" alt="logo">
                <nav>
                    <ul id="menu">
                        <li><a href="covid.php">Home</a></li>
                        <li><a href="Patient.php">Patient</a></li>
                        <li><a href="work.php">Stuff</a></li>
                        <li><a href="aboutus.php">About Us</a></li>
                        <li><a href="aboutus.php">something</a></li>
                    </ul>
                </nav>
            </header>

            <?php
            error_reporting(0);
            include 'connectdb.php';
            $fun = $_POST['fun'];
            switch ($fun) {
                case 'fun1':
                    if (isset($_POST['PatientSubmit2'])) {
                        $Fname = $_POST["Fname"];
                        $Lname = $_POST["Lname"];
                        $Ohip = $_POST["Ohip"];
                        $Birth = $_POST["Birth"];


                        $connection->query("INSERT INTO patient (Ohip,FirstName,LastName,DateOfBirth) VALUES ('$Ohip','$Fname','$Lname','$Birth')");
                    }
                    echo "<p>The patient information has been successfullly inserted</p>";
                    break;
                case 'fun2':
                    if (isset($_POST['PatientSubmit3'])) {
                        $OHIP = $_SESSION['id'];
                        $date = $_POST["date"];
                        $clinic = $_POST["clinic"];
                        $lotnum = $_POST["lotnum"];
                        $time = $_POST["time"];
                        $connection->query("INSERT INTO vaccination (VaccinationDate,VaccinationTime,LotNum,ClinicName,PatientOhip) VALUES ('$date','$time','$lotnum','$clinic','$OHIP')");
                        $result = $connection->query("select * FROM patient P join vaccination V on P.Ohip=V.PatientOhip join vaccine E on V.LotNum=E.LotNumber WHERE Ohip='" . $OHIP . "'");
                        $row2 = $result->fetchAll();
                        echo "<div id='table'>";
                        echo "<table>";
                        echo "<tr class='list'>";
                        echo "<th>FirstName</th>";
                        echo "<th>LastName</th>";
                        echo "<th>Ohip</th>";
                        echo "<th>LotNum</th>";
                        echo "<th>ClinicName</th>";
                        echo "<th>CompanyName</th>";
                        echo "<th>VaccinationDate</th>";
                        echo "</tr>";

                        for ($i = 0; $i < sizeof($row2); $i++) {
                            echo "<tr class='list'>";
                            echo "<td class='listelement'>";
                            echo $row2[$i]["FirstName"];
                            echo "</td>";
                            echo "<td class='listelement'>";
                            echo $row2[$i]["LastName"];
                            echo "</td>";
                            echo "<td class='listelement'>";
                            echo $row2[$i]["Ohip"];
                            echo "</td>";
                            echo "<td class='listelement'>";
                            echo $row2[$i]["LotNum"];
                            echo "</td>";
                            echo "<td class='listelement'>";
                            echo $row2[$i]["ClinicName"];
                            echo "</td>";
                            echo "<td class='listelement'>";
                            echo $row2[$i]["CompanyName"];
                            echo "</td>";
                            echo "<td class='listelement'>";
                            echo $row2[$i]["VaccinationDate"];
                            echo "</td>";
                            echo "</tr>";
                        }

                        echo "</table>";
                        echo "</div>";
                    }

                    break;
            }



            ?>

            <a href="Patient.php">Go Back</a>
        </div>
    </div>

</body>

</html>